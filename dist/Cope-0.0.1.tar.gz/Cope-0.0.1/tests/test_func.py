from os.path import join, dirname; import sys; sys.path.append(join(dirname( __file__ ), '..'))
from Cope.func import *

def test_FunctionCall():
    FunctionCall

def test_Signal():
    Signal
