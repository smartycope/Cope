__version__ = '1.3.0'
from .debugging import debug
from .debugging import printArgs
from .decorators import *
from .imports import *
from .geometry import *
from .logging import *
from .misc import *
from .key import *
from .point import *
from .timing import *
from .prettyTable import *
from .iterables import *
from .func import *
from . import colors
from ._config import config as CopeConfig
# from . import _config as confi
from .errors import *
# from .linalg import *
