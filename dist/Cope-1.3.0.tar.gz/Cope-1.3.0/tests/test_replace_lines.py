from Cope import *

# line3
# replaceLine('teeeeeeeeeeeeeeest')
# line 5

# comment('commeeennnttttt')
comment('commeeennnttttt')

# comment('')
comment('')

# comment(' ')
comment(' ')

# comment('comemnt', char='~')
comment('comemnt', char='~')

# comment('comment', start=' ')
comment('comment', start=' ')

# comment('comment', start='!', end='!')
comment('comment', start='!', end='!')

# comment('comment', line_limit=60)
comment('comment', line_limit=60)

# comment('commant', char='')
comment('commant', char='')

# comment('commant', char='-~')
comment('commant', char='-~')

# comment('commant', start='$-$')
comment('commant', start='$-$')

# comment('commant', end='$-$')
comment('commant', end='$-$')
