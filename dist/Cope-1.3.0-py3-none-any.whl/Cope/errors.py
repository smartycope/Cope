class ReadOnlyError(Exception):
    pass
