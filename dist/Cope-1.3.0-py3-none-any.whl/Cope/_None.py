# A unique dummy class for parameters
class _None: pass
